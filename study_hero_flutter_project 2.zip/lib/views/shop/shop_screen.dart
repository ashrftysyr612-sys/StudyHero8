import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/quiz_provider.dart';

class ShopScreen extends StatelessWidget {
  const ShopScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final quizProvider = Provider.of<QuizProvider>(context);
    final stats = quizProvider.userStats;

    // تعريف قائمة الأفاتارات (أفاتار افتراضي و9 أفاتارات قابلة للشراء)
    final List<Map<String, dynamic>> avatars = List.generate(10, (index) {
      final id = index + 1;
      return {
        'id': 'avatar_${id}',
        'name': 'أفاتار البطل ${id}',
        'price': id == 1 ? 0 : id * 30, // الأول مجاني ثم أسعار متزايدة
        'icon': Icons.account_circle,
      };
    });

    // تعريف قائمة السمات المتوفرة
    final List<Map<String, dynamic>> themes = [
      {'id': 'dark_purple', 'name': 'السمة البنفسجية الداكنة', 'price': 0, 'color': const Color(0xFF9D4EDD)},
      {'id': 'cosmic_blue', 'name': 'سمة أزرق الفضاء الكوني', 'price': 100, 'color': const Color(0xFF0077B6)},
      {'id': 'royal_gold', 'name': 'سمة الذهب الملكي الفاخر', 'price': 250, 'color': const Color(0xFFD4AF37)},
    ];

    return DefaultTabController(
      length: 2,
      child: Scaffold(
        backgroundColor: theme.scaffoldBackgroundColor,
        appBar: AppBar(
          title: const Text('متجر بطل الدراسة'),
          actions: [
            Row(
              children: [
                const Icon(Icons.monetization_on, color: Colors.amber),
                const SizedBox(width: 4),
                Text(
                  '${stats.coins}',
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.amber),
                ),
                const SizedBox(width: 16),
              ],
            )
          ],
          bottom: TabBar(
            labelColor: theme.colorScheme.primary,
            unselectedLabelColor: theme.colorScheme.onSurface.withOpacity(0.5),
            indicatorColor: theme.colorScheme.primary,
            tabs: const [
              Tab(icon: Icon(Icons.face_retouching_natural), text: 'الأفاتار'),
              Tab(icon: Icon(Icons.palette), text: 'السمات'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            // تصفح واختيار الأفاتار
            GridView.builder(
              padding: const EdgeInsets.all(16),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                mainAxisExtent: 160,
              ),
              itemCount: avatars.length,
              itemBuilder: (context, index) {
                final avatar = avatars[index];
                final isUnlocked = stats.unlockedAvatars.contains(avatar['id']);
                final isActive = stats.currentAvatar == avatar['id'];
                
                return Card(
                  color: isActive ? theme.colorScheme.primary.withOpacity(0.1) : null,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: isActive ? theme.colorScheme.primary : Colors.grey.withOpacity(0.2),
                      width: 1.5,
                    ),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        CircleAvatar(
                          backgroundColor: theme.colorScheme.primary.withOpacity(0.1),
                          child: Icon(avatar['icon'], color: theme.colorScheme.primary, size: 32),
                        ),
                        const SizedBox(height: 8),
                        Text(avatar['name'], style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                        const SizedBox(height: 8),
                        ElevatedButton(
                          onPressed: () async {
                            bool success = await quizProvider.buyAvatar(avatar['id'], avatar['price']);
                            if (context.mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text(
                                    success 
                                        ? (isUnlocked ? 'تم تفعيل الأفاتار بنجاح!' : 'مبارك! قمت بشراء الأفاتار بنجاح.') 
                                        : 'رصيد عملاتك غير كافٍ لإلغاء القفل!',
                                    textAlign: TextAlign.center,
                                  ),
                                  backgroundColor: success ? Colors.green : Colors.redAccent,
                                ),
                              );
                            }
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: isActive ? Colors.green : (isUnlocked ? Colors.grey.shade800 : null),
                            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                          ),
                          child: Text(
                            isActive ? 'نشط' : (isUnlocked ? 'تفعيل' : '${avatar['price']} عملة'),
                            style: const TextStyle(fontSize: 11),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
            
            // تصفح واختيار السمة
            ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: themes.length,
              itemBuilder: (context, index) {
                final appTheme = themes[index];
                final isUnlocked = stats.unlockedThemes.contains(appTheme['id']);
                final isActive = stats.currentTheme == appTheme['id'];
                
                return Card(
                  margin: const EdgeInsets.only(bottom: 12),
                  child: ListTile(
                    leading: Container(
                      width: 24,
                      height: 24,
                      decoration: BoxDecoration(color: appTheme['color'], shape: BoxShape.circle),
                    ),
                    title: Text(appTheme['name'], style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text(isActive ? 'المظهر النشط حالياً' : (isUnlocked ? 'مفتوح للتبديل' : 'السعر: ${appTheme['price']} كوينز')),
                    trailing: ElevatedButton(
                      onPressed: () async {
                        bool success = await quizProvider.buyTheme(appTheme['id'], appTheme['price']);
                        if (context.mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text(
                                success ? 'تم تفعيل السمة الجديدة بنجاح!' : 'رصيد عملاتك غير كافٍ!',
                                textAlign: TextAlign.center,
                              ),
                              backgroundColor: success ? Colors.green : Colors.red,
                            ),
                          );
                        }
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: isActive ? Colors.green : (isUnlocked ? Colors.grey : null),
                      ),
                      child: Text(isActive ? 'نشط' : (isUnlocked ? 'تطبيق' : 'شراء')),
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
