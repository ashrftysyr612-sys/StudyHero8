import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/quiz_provider.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final quizProvider = Provider.of<QuizProvider>(context);

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      appBar: AppBar(
        title: const Text('إعدادات اللعبة وبطل الدراسة'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // لوحة تحكم بالصوت والمؤثرات الصوتية المطلوبة
          Card(
            child: SwitchListTile(
              secondary: Icon(
                quizProvider.isSoundEnabled ? Icons.volume_up : Icons.volume_off,
                color: theme.colorScheme.primary,
              ),
              title: const Text('المؤثرات الصوتية للعبة', style: TextStyle(fontWeight: FontWeight.bold)),
              subtitle: const Text('تشغيل أصوات المكافآت، الإجابة الصحيحة والخاطئة'),
              value: quizProvider.isSoundEnabled,
              onChanged: (bool value) {
                quizProvider.toggleSound(value);
              },
            ),
          ),
          
          const SizedBox(height: 12),
          
          // قسم المساعدة والتوجيهات للتثبيت وبناء APK
          Card(
            child: ExpansionTile(
              leading: Icon(Icons.build, color: theme.colorScheme.primary),
              title: const Text('خطوات بناء ملف الـ APK والتثبيت', style: TextStyle(fontWeight: FontWeight.bold)),
              children: const [
                Padding(
                  padding: EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('1. ثبّت بيئة Flutter و Android SDK على جهازك.', style: TextStyle(fontSize: 13)),
                      SizedBox(height: 6),
                      Text('2. قم بإنشاء مشروع جديد عبر أمر:
    flutter create study_hero', style: TextStyle(fontSize: 13, fontFamily: 'monospace')),
                      SizedBox(height: 6),
                      Text('3. انسخ الملفات وهيكل المجلدات الموضح باليسار وضعها بمشروعك.', style: TextStyle(fontSize: 13)),
                      SizedBox(height: 6),
                      Text('4. نزّل حزم الاعتماديات بكتابة:
    flutter pub get', style: TextStyle(fontSize: 13, fontFamily: 'monospace')),
                      SizedBox(height: 6),
                      Text('5. قم ببناء ملف الـ APK النهائي بإصدار الإنتاج عبر تشغيل:
    flutter build apk --release', style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: Colors.green)),
                    ],
                  ),
                )
              ],
            ),
          ),
          
          const SizedBox(height: 12),
          
          // مسح كامل البيانات الحالية وإعادة ضبط المصنع
          Card(
            color: Colors.red.withOpacity(0.05),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.red.withOpacity(0.3)),
            ),
            child: ListTile(
              leading: const Icon(Icons.delete_forever, color: Colors.redAccent),
              title: const Text('إعادة تهيئة كامل البيانات وتحرير المستوى', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.redAccent)),
              subtitle: const Text('سيتم تصفير رصيد كوينز والـ XP ومسح تقدم المستويات الحالي بالكامل!'),
              onTap: () {
                _showResetConfirmDialog(context, quizProvider);
              },
            ),
          ),
          
          const SizedBox(height: 40),
          
          const Center(
            child: Text(
              'StudyHero v1.0.0 © 2026',
              style: TextStyle(fontSize: 12, color: Colors.grey),
            ),
          )
        ],
      ),
    );
  }

  void _showResetConfirmDialog(BuildContext context, QuizProvider provider) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('تأكيد إعادة التهيئة بالكامل؟', textAlign: TextAlign.center),
          content: const Text(
            'هل أنت متأكد تماماً من رغبتك في تصفير تقدمك بالكامل والبدء من جديد كبطل جديد؟ هذا الإجراء لا يمكن التراجع عنه.',
            textAlign: TextAlign.center,
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('إلغاء'),
            ),
            TextButton(
              onPressed: () async {
                await provider.resetAllData();
                if (context.mounted) {
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('تم تصفير وإعادة تعيين جميع تفضيلاتك بنجاح!', textAlign: TextAlign.center),
                      backgroundColor: Colors.green,
                    ),
                  );
                }
              },
              style: TextButton.styleFrom(foregroundColor: Colors.red),
              child: const Text('نعم، صفّر الآن'),
            ),
          ],
        );
      },
    );
  }
}
