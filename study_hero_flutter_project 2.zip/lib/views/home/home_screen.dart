import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/quiz_provider.dart';
import '../quiz/quiz_screen.dart';
import '../shop/shop_screen.dart';
import '../leaderboard/leaderboard_screen.dart';
import '../statistics/statistics_screen.dart';
import '../settings/settings_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final quizProvider = Provider.of<QuizProvider>(context);
    final stats = quizProvider.userStats;

    // تعريف المواد الأربعة المطلوبة
    final List<Map<String, dynamic>> subjects = [
      {
        'id': 'math',
        'name': 'الرياضيات',
        'icon': Icons.calculate,
        'color': const Color(0xFF9D4EDD),
        'desc': 'مسائل الحساب والجبر والذكاء الهندسي'
      },
      {
        'id': 'science',
        'name': 'العلوم',
        'icon': Icons.science,
        'color': const Color(0xFF0077B6),
        'desc': 'استكشف الفضاء، جسم الإنسان وعجائب الفيزياء'
      },
      {
        'id': 'english',
        'name': 'اللغة الإنجليزية',
        'icon': Icons.translate,
        'color': const Color(0xFF2A9D8F),
        'desc': 'اختبارات المفردات والجرامر والقراءة والترجمة'
      },
      {
        'id': 'history',
        'name': 'التاريخ',
        'icon': Icons.history_edu,
        'color': const Color(0xFFE76F51),
        'desc': 'أعظم القصص والمعارك التاريخية والحضارات القديمة'
      }
    ];

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      
      // شريط علوي معلق مع لوحة بيانات اللاعب
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Row(
          children: [
            // صورة الأفاتار الحالي للمستخدم
            CircleAvatar(
              backgroundColor: theme.colorScheme.primary.withOpacity(0.2),
              child: Icon(Icons.person, color: theme.colorScheme.primary),
            ),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  stats.username,
                  style: theme.textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.bold),
                ),
                Text(
                  'مستوى اللاعب ${stats.playerLevel}',
                  style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.primary),
                ),
              ],
            ),
          ],
        ),
        actions: [
          // العملات الحالية
          Row(
            children: [
              Icon(Icons.monetization_on, color: Colors.amber, size: 20),
              const SizedBox(width: 4),
              Text(
                '${stats.coins}',
                style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.amber),
              ),
            ],
          ),
          const SizedBox(width: 16),
          // نقاط الـ XP
          Row(
            children: [
              Icon(Icons.star, color: Colors.purpleAccent, size: 20),
              const SizedBox(width: 4),
              Text(
                '${stats.xp} XP',
                style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.purpleAccent),
              ),
            ],
          ),
          const SizedBox(width: 16),
        ],
      ),
      
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // الكارد الترحيبي مع المكافأة اليومية
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'المكافأة اليومية جاهزة!',
                            style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'احصل على 20 كوينز مجانية لدعم بطولتك لليوم.',
                            style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurface.withOpacity(0.7)),
                          ),
                          const SizedBox(height: 12),
                          ElevatedButton(
                            onPressed: () async {
                              bool claimed = await quizProvider.claimDailyReward();
                              if (context.mounted) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text(
                                      claimed ? 'تهانينا! حصلت على 20 كوينز.' : 'لقد حصلت على مكافأة اليوم مسبقاً!',
                                      textAlign: TextAlign.center,
                                    ),
                                    backgroundColor: claimed ? Colors.green : Colors.redAccent,
                                  ),
                                );
                              }
                            },
                            child: const Text('احصل الآن'),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 12),
                    Icon(Icons.card_giftcard, size: 64, color: theme.colorScheme.primary),
                  ],
                ),
              ),
            ),
            
            const SizedBox(height: 24),
            
            Text(
              'اختر مادة التحدي',
              style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
            ),
            
            const SizedBox(height: 12),
            
            // شبكة عرض المواد الأربعة
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 1,
                mainAxisExtent: 130,
                mainAxisSpacing: 12,
              ),
              itemCount: subjects.length,
              itemBuilder: (context, index) {
                final subject = subjects[index];
                final progress = stats.subjectLevelsProgress[subject['id']] ?? 1;
                
                return Card(
                  clipBehavior: Clip.antiAlias,
                  elevation: 2,
                  child: InkWell(
                    onTap: () {
                      _showLevelsModal(context, subject, progress);
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(16),
                            decoration: BoxDecoration(
                              color: subject['color'].withOpacity(0.15),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: subject['color'], width: 1.5),
                            ),
                            child: Icon(subject['icon'], color: subject['color'], size: 36),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  subject['name'],
                                  style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  subject['desc'],
                                  style: theme.textTheme.bodySmall?.copyWith(
                                    color: theme.colorScheme.onSurface.withOpacity(0.6),
                                  ),
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                ),
                                const SizedBox(height: 6),
                                Text(
                                  'مستوى التقدم الحالي: ${progress} / 5',
                                  style: TextStyle(color: subject['color'], fontWeight: FontWeight.bold, fontSize: 12),
                                ),
                              ],
                            ),
                          ),
                          Icon(Icons.arrow_forward_ios, size: 16, color: theme.colorScheme.onSurface.withOpacity(0.5)),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
            
            const SizedBox(height: 32),
          ],
        ),
      ),
      
      // شريط تنقل سفلي حديث
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: 0,
        type: BottomNavigationBarType.fixed,
        selectedItemColor: theme.colorScheme.primary,
        unselectedItemColor: theme.colorScheme.onSurface.withOpacity(0.5),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'الرئيسية'),
          BottomNavigationBarItem(icon: Icon(Icons.emoji_events), label: 'المتصدرين'),
          BottomNavigationBarItem(icon: Icon(Icons.shopping_bag), label: 'المتجر'),
          BottomNavigationBarItem(icon: Icon(Icons.bar_chart), label: 'الإحصائيات'),
          BottomNavigationBarItem(icon: Icon(Icons.settings), label: 'الإعدادات'),
        ],
        onTap: (index) {
          switch (index) {
            case 1:
              Navigator.push(context, MaterialPageRoute(builder: (_) => const LeaderboardScreen()));
              break;
            case 2:
              Navigator.push(context, MaterialPageRoute(builder: (_) => const ShopScreen()));
              break;
            case 3:
              Navigator.push(context, MaterialPageRoute(builder: (_) => const StatisticsScreen()));
              break;
            case 4:
              Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsScreen()));
              break;
          }
        },
      ),
    );
  }

  // عرض نافذة المستويات (5 مستويات لكل مادة)
  void _showLevelsModal(BuildContext context, Map<String, dynamic> subject, int currentUnlockedLevel) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (context) {
        return Container(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'مستويات مادة ${subject['name']}',
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
              ),
              const SizedBox(height: 16),
              Flexible(
                child: ListView.builder(
                  shrinkWrap: true,
                  itemCount: 5,
                  itemBuilder: (context, index) {
                    final levelNum = index + 1;
                    final isLocked = levelNum > currentUnlockedLevel;
                    
                    return ListTile(
                      leading: CircleAvatar(
                        backgroundColor: isLocked ? Colors.grey.withOpacity(0.2) : subject['color'].withOpacity(0.2),
                        child: Text(
                          '${levelNum}',
                          style: TextStyle(
                            color: isLocked ? Colors.grey : subject['color'],
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      title: Text('المستوى ${levelNum}'),
                      trailing: Icon(
                        isLocked ? Icons.lock : Icons.play_arrow,
                        color: isLocked ? Colors.grey : subject['color'],
                      ),
                      enabled: !isLocked,
                      onTap: () {
                        Navigator.pop(context); // غلق المودال
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => QuizScreen(
                              subjectId: subject['id'],
                              subjectName: subject['name'],
                              level: levelNum,
                            ),
                          ),
                        );
                      },
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
