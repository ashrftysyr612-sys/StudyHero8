package com.studyhero.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
