import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/quiz_provider.dart';

class StatisticsScreen extends StatelessWidget {
  const StatisticsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final quizProvider = Provider.of<QuizProvider>(context);
    final stats = quizProvider.userStats;

    // قياس إحصائيات مستويات تقدم المواد
    int totalLevelsUnlocked = 0;
    stats.subjectLevelsProgress.forEach((key, value) {
      totalLevelsUnlocked += value - 1; // كم مستوى اكتمل (إذا كان مفتوح له 3 يعني اكتمل 2)
    });

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      appBar: AppBar(
        title: const Text('إحصائيات الإنجازات والتقدم'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // لوحة أرقام وإحصائيات سريعة
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _buildStatCol(context, 'المستوى الحالي', '${stats.playerLevel}', Icons.trending_up, Colors.amber),
                    _buildStatCol(context, 'المستويات المكتملة', '${totalLevelsUnlocked}', Icons.check_circle_outline, Colors.green),
                    _buildStatCol(context, 'الإنجازات المفتوحة', '${stats.completedAchievements.length} / 5', Icons.emoji_events, Colors.purpleAccent),
                  ],
                ),
              ),
            ),
            
            const SizedBox(height: 24),
            
            Text(
              'التقدم لكل مادة من المواد الأربعة',
              style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
            ),
            
            const SizedBox(height: 12),
            
            // مؤشرات تقدم تقدم المواد الأربعة بالتفصيل
            _buildProgressRow(context, 'الرياضيات', stats.subjectLevelsProgress['math'] ?? 1, const Color(0xFF9D4EDD)),
            _buildProgressRow(context, 'العلوم', stats.subjectLevelsProgress['science'] ?? 1, const Color(0xFF0077B6)),
            _buildProgressRow(context, 'الاللغة الإنجليزية', stats.subjectLevelsProgress['english'] ?? 1, const Color(0xFF2A9D8F)),
            _buildProgressRow(context, 'التاريخ', stats.subjectLevelsProgress['history'] ?? 1, const Color(0xFFE76F51)),
            
            const SizedBox(height: 24),
            
            Text(
              'أوسمة وإنجازات البطل المطلوبة',
              style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
            ),
            
            const SizedBox(height: 12),
            
            _buildAchievementItem(
              context,
              'بطل صاعد',
              'قم بترقية مستوى حساب البطل الخاص بك إلى المستوى الثاني.',
              stats.completedAchievements.contains('level_up'),
            ),
            _buildAchievementItem(
              context,
              'بطل المواظبة',
              'قم بالمطالبة بمكافأتك اليومية لليوم لتأكيد تفاعلك.',
              stats.completedAchievements.contains('daily_claim'),
            ),
            _buildAchievementItem(
              context,
              'جامع الأفاتارز',
              'قم بإلغاء القفل لـ 5 صور أفاتار مميزة لتعيين شكل بروفايل مخصص.',
              stats.completedAchievements.contains('avatar_collector'),
            ),
            _buildAchievementItem(
              context,
              'الفاتح العظيم',
              'افتح المستوى الخامس والأخير لجميع المواد الأربعة بالكامل.',
              stats.completedAchievements.contains('conqueror'),
            ),
            
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }

  Widget _buildStatCol(BuildContext context, String label, String value, IconData icon, Color color) {
    final theme = Theme.of(context);
    return Column(
      children: [
        Icon(icon, color: color, size: 28),
        const SizedBox(height: 8),
        Text(value, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
        const SizedBox(height: 4),
        Text(label, style: TextStyle(fontSize: 10, color: theme.colorScheme.onSurface.withOpacity(0.6))),
      ],
    );
  }

  Widget _buildProgressRow(BuildContext context, String subject, int progressLevel, Color color) {
    final double percent = (progressLevel - 1) / 4.0; // 0.0 to 1.0
    return Padding(
      padding: const EdgeInsets.only(bottom: 12.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(subject, style: const TextStyle(fontWeight: FontWeight.bold)),
              Text('مستوى ${progressLevel} / 5', style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 13)),
            ],
          ),
          const SizedBox(height: 4),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: percent,
              minHeight: 8,
              backgroundColor: Colors.grey.withOpacity(0.2),
              valueColor: AlwaysStoppedAnimation<Color>(color),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAchievementItem(BuildContext context, String title, String desc, bool isUnlocked) {
    final theme = Theme.of(context);
    
    return Card(
      color: isUnlocked ? theme.colorScheme.primary.withOpacity(0.08) : Colors.black12,
      child: ListTile(
        leading: Icon(
          isUnlocked ? Icons.emoji_events : Icons.lock,
          color: isUnlocked ? Colors.amber : Colors.grey,
          size: 32,
        ),
        title: Text(
          title,
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: isUnlocked ? theme.colorScheme.onSurface : Colors.grey,
          ),
        ),
        subtitle: Text(desc, style: const TextStyle(fontSize: 11)),
        trailing: isUnlocked 
            ? const Chip(label: Text('اكتمل', style: TextStyle(fontSize: 10, color: Colors.green)))
            : const Chip(label: Text('مغلق', style: TextStyle(fontSize: 10))),
      ),
    );
  }
}
