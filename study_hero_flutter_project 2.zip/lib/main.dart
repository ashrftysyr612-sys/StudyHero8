import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';
import 'core/theme/app_theme.dart';
import 'providers/quiz_provider.dart';
import 'views/splash/splash_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // تثبيت اتجاه الشاشة عمودياً فقط للحفاظ على تناسق التصميم الموجه للهواتف
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  // تهيئة مستودع تفضيلات المستخدم وحفظ البيانات محلياً
  final quizProvider = QuizProvider();
  await quizProvider.init();

  runApp(
    ChangeNotifierProvider<QuizProvider>.value(
      value: quizProvider,
      child: const StudyHeroApp(),
    ),
  );
}

class StudyHeroApp extends StatelessWidget {
  const StudyHeroApp({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<QuizProvider>(
      builder: (context, provider, child) {
        return MaterialApp(
          title: 'StudyHero - بطل الدراسة',
          debugShowCheckedModeBanner: false,
          
          // إعدادات اللغة العربية ودعم التخطيط من اليمين إلى اليسار (RTL)
          locale: const Locale('ar', 'AE'),
          localizationsDelegates: const [
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          supportedLocales: const [
            Locale('ar', 'AE'), // العربية كاللغة الافتراضية
          ],
          
          // تطبيق السمات المخصصة من متجر المظاهر والسمات
          theme: AppTheme.getThemeByName(provider.currentTheme),
          home: const SplashScreen(),
        );
      },
    );
  }
}
