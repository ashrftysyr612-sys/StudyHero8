import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/quiz_provider.dart';
import '../home/home_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _usernameController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  void _submit(bool isGuest) async {
    final provider = Provider.of<QuizProvider>(context, listen: false);
    
    String name = "بطل الدراسة";
    if (!isGuest) {
      if (!_formKey.currentState!.validate()) return;
      name = _usernameController.text.trim();
    }
    
    await provider.setUsername(name);
    
    if (!mounted) return;
    
    // الانتقال للرئيسية
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => const HomeScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 40),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SizedBox(height: 20),
              
              // أيقونة التطبيق الكبيرة والعصرية
              Center(
                child: Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: theme.colorScheme.primary.withOpacity(0.1),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    Icons.school_rounded,
                    size: 72,
                    color: theme.colorScheme.primary,
                  ),
                ),
              ),
              
              const SizedBox(height: 32),
              
              Center(
                child: Text(
                  'أهلاً بك في StudyHero',
                  style: theme.textTheme.headlineMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              
              const SizedBox(height: 8),
              
              Center(
                child: Text(
                  'تحدّ نفسك، اجمع الكوينز، وكن بطلاً للمعلومات!',
                  textAlign: TextAlign.center,
                  style: theme.textTheme.bodyMedium?.copyWith(
                    color: theme.colorScheme.onBackground.withOpacity(0.7),
                  ),
                ),
              ),
              
              const SizedBox(height: 48),
              
              // نموذج التسجيل
              Form(
                key: _formKey,
                child: TextFormField(
                  controller: _usernameController,
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.right,
                  decoration: InputDecoration(
                    labelText: 'اسم البطل',
                    labelStyle: TextStyle(color: theme.colorScheme.primary),
                    hintText: 'أدخل اسمك المستعار هنا',
                    prefixIcon: Icon(Icons.person, color: theme.colorScheme.primary),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: BorderSide(color: theme.colorScheme.primary, width: 2),
                    ),
                  ),
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'يرجى إدخال اسمك أولاً';
                    }
                    if (value.length < 3) {
                      return 'يجب أن يتكون الاسم من 3 أحرف على الأقل';
                    }
                    return null;
                  },
                ),
              ),
              
              const SizedBox(height: 24),
              
              // زر إنشاء حساب بطل
              ElevatedButton(
                onPressed: () => _submit(false),
                child: const Text(
                  'ابدأ المغامرة',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ),
              
              const SizedBox(height: 16),
              
              // زر الدخول كزائر بسرعة
              OutlinedButton(
                onPressed: () => _submit(true),
                style: OutlinedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  side: BorderSide(color: theme.colorScheme.primary),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                child: Text(
                  'الدخول كزائر سريع',
                  style: TextStyle(color: theme.colorScheme.primary, fontSize: 16, fontWeight: FontWeight.bold),
                ),
              ),
              
              const SizedBox(height: 40),
            ],
          ),
        ),
      ),
    );
  }
}
