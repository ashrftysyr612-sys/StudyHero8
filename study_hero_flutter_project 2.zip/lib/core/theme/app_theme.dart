import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  // مظهر أرجواني داكن عصري (المظهر الافتراضي للمطوّر)
  static ThemeData get darkPurpleTheme {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      colorScheme: const ColorScheme.dark(
        primary: Color(0xFF9D4EDD),      // أرجواني مشع
        secondary: Color(0xFFC77DFF),    // أرجواني فاتح
        surface: Color(0xFF1E1A24),      // سطح كرت داكن
        background: Color(0xFF120E16),   // خلفية داكنة عميقة
        error: Color(0xFFFF5A5F),
        onPrimary: Colors.white,
        onSecondary: Colors.white,
        onSurface: Color(0xFFE5E1E6),
        onBackground: Color(0xFFF3EFF5),
      ),
      scaffoldBackgroundColor: const Color(0xFF120E16),
      textTheme: GoogleFonts.tajawalTextTheme(ThemeData.dark().textTheme).copyWith(
        titleLarge: GoogleFonts.tajawal(fontWeight: FontWeight.bold, fontSize: 22),
        bodyMedium: GoogleFonts.tajawal(fontSize: 16),
      ),
      cardTheme: CardTheme(
        color: const Color(0xFF1E1A24),
        elevation: 4,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFF9D4EDD),
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 24),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      ),
    );
  }

  // مظهر أزرق فضائي بديل (متاح للشراء في المتجر)
  static ThemeData get cosmicBlueTheme {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      colorScheme: const ColorScheme.dark(
        primary: Color(0xFF0077B6),      // أزرق فلكي
        secondary: Color(0xFF00B4D8),    // أزرق سماوي مشرق
        surface: Color(0xFF132237),      // كرت كحلي داكن
        background: Color(0xFF0B132B),   // خلفية الفضاء العميقة
        error: Color(0xFFFF5A5F),
        onPrimary: Colors.white,
        onSecondary: Colors.white,
        onSurface: Color(0xFFE2EAFC),
        onBackground: Color(0xFFEDF2FB),
      ),
      scaffoldBackgroundColor: const Color(0xFF0B132B),
      textTheme: GoogleFonts.tajawalTextTheme(ThemeData.dark().textTheme),
      cardTheme: CardTheme(
        color: const Color(0xFF132237),
        elevation: 4,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFF0077B6),
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 24),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      ),
    );
  }

  // مظهر الذهب الملكي (متاح للشراء في المتجر)
  static ThemeData get royalGoldTheme {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      colorScheme: const ColorScheme.dark(
        primary: Color(0xFFD4AF37),      // ذهبي ملكي
        secondary: Color(0xFFFFD700),    // أصفر ذهبي مشرق
        surface: Color(0xFF221F17),      // سطح برونزي داكن
        background: Color(0xFF12110E),   // خلفية داكنة ملكية
        error: Color(0xFFFF5A5F),
        onPrimary: Colors.black,
        onSecondary: Colors.black,
        onSurface: Color(0xFFECE5D8),
        onBackground: Color(0xFFF6F0E5),
      ),
      scaffoldBackgroundColor: const Color(0xFF12110E),
      textTheme: GoogleFonts.tajawalTextTheme(ThemeData.dark().textTheme),
      cardTheme: CardTheme(
        color: const Color(0xFF221F17),
        elevation: 4,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFFD4AF37),
          foregroundColor: Colors.black,
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 24),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      ),
    );
  }

  static ThemeData getThemeByName(String themeName) {
    switch (themeName) {
      case 'cosmic_blue':
        return cosmicBlueTheme;
      case 'royal_gold':
        return royalGoldTheme;
      case 'dark_purple':
      default:
        return darkPurpleTheme;
    }
  }
}
