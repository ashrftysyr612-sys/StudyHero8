import 'package:flutter/material.dart';
import 'package:percent_indicator/linear_percent_indicator.dart';
import 'package:provider/provider.dart';
import '../../data/models/question_model.dart';
import '../../data/repositories/quiz_repository.dart';
import '../../providers/quiz_provider.dart';

class QuizScreen extends StatefulWidget {
  final String subjectId;
  final String subjectName;
  final int level;

  const QuizScreen({
    super.key,
    required this.subjectId,
    required this.subjectName,
    required this.level,
  });

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  late List<QuestionModel> _questions;
  int _currentQuestionIndex = 0;
  int? _selectedAnswerIndex;
  bool _isAnswered = false;
  int _correctAnswersCount = 0;
  int _earnedCoins = 0;
  int _earnedXp = 0;

  @override
  void initState() {
    super.initState();
    // جلب الأسئلة العشوائية للمادة والمستوى
    _questions = QuizRepository.getQuestions(widget.subjectId, widget.level);
  }

  void _answerQuestion(int optionIndex) {
    if (_isAnswered) return;

    setState(() {
      _selectedAnswerIndex = optionIndex;
      _isAnswered = true;
      
      final isCorrect = optionIndex == _questions[_currentQuestionIndex].correctIndex;
      
      if (isCorrect) {
        _correctAnswersCount++;
        _earnedCoins += 10;
        _earnedXp += 10;
        
        // تشغيل صوت الإجابة الصحيحة المحاكى
      } else {
        // تشغيل صوت الإجابة الخاطئة المحاكى
      }
    });
  }

  void _nextQuestion() {
    if (_currentQuestionIndex < _questions.length - 1) {
      setState(() {
        _currentQuestionIndex++;
        _selectedAnswerIndex = null;
        _isAnswered = false;
      });
    } else {
      // إتمام المستوى وحساب النتائج النهائية وتخزينها
      _finishQuiz();
    }
  }

  void _finishQuiz() async {
    final provider = Provider.of<QuizProvider>(context, listen: false);
    
    // حفظ المكافآت الحاصل عليها المستخدم محلياً
    if (_earnedCoins > 0) {
      await provider.addRewards(_earnedXp, _earnedCoins);
    }
    
    // إذا أجاب على 7 أسئلة أو أكثر بشكل صحيح نفتح له المستوى التالي
    bool isPassed = _correctAnswersCount >= 7;
    if (isPassed) {
      await provider.unlockNextLevel(widget.subjectId, widget.level);
    }

    if (!mounted) return;

    _showResultDialog(isPassed);
  }

  void _showResultDialog(bool isPassed) {
    final theme = Theme.of(context);
    
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return AlertDialog(
          title: Text(
            isPassed ? 'تهانينا، لقد نجحت!' : 'لم توفق هذه المرة!',
            textAlign: TextAlign.center,
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                isPassed ? Icons.emoji_events : Icons.sentiment_very_dissatisfied,
                size: 80,
                color: isPassed ? Colors.amber : Colors.redAccent,
              ),
              const SizedBox(height: 16),
              Text(
                'النتيجة: ${_correctAnswersCount} / ${_questions.length}',
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.monetization_on, color: Colors.amber),
                  const SizedBox(width: 4),
                  Text('+${_earnedCoins} كوينز', style: const TextStyle(color: Colors.amber, fontWeight: FontWeight.bold)),
                  const SizedBox(width: 16),
                  const Icon(Icons.star, color: Colors.purpleAccent),
                  const SizedBox(width: 4),
                  Text('+${_earnedXp} XP', style: const TextStyle(color: Colors.purpleAccent, fontWeight: FontWeight.bold)),
                ],
              ),
              const SizedBox(height: 16),
              Text(
                isPassed ? 'لقد تم فتح المستوى التالي!' : 'حاول الإجابة على 7 أسئلة صحيحة لفتح المستوى التالي.',
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 13, color: Colors.grey),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context); // غلق الديالوج
                Navigator.pop(context); // الرجوع للرئيسية
              },
              child: const Text('العودة للرئيسية'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    if (_questions.isEmpty) {
      return Scaffold(
        body: Center(child: Text('عذراً، لا توجد أسئلة متوفرة حالياً لهذا المستوى.')),
      );
    }

    final currentQuestion = _questions[_currentQuestionIndex];
    final progressPercentage = (_currentQuestionIndex + 1) / _questions.length;

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text('${widget.subjectName} - المستوى ${widget.level}'),
        leading: IconButton(
          icon: const Icon(Icons.close),
          onPressed: () {
            // تنبيه لتأكيد رغبة المغادرة
            Navigator.pop(context);
          },
        ),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // شريط تقدم الأسئلة
              Row(
                children: [
                  Text('${_currentQuestionIndex + 1} / ${_questions.length}'),
                  const SizedBox(width: 8),
                  Expanded(
                    child: LinearPercentIndicator(
                      lineHeight: 8.0,
                      percent: progressPercentage,
                      backgroundColor: Colors.grey.withOpacity(0.2),
                      progressColor: theme.colorScheme.primary,
                      barRadius: const Radius.circular(4),
                      padding: EdgeInsets.zero,
                    ),
                  ),
                ],
              ),
              
              const SizedBox(height: 32),
              
              // نص السؤال الحالي
              Expanded(
                flex: 3,
                child: Center(
                  child: Card(
                    child: Padding(
                      padding: const EdgeInsets.all(24.0),
                      child: Text(
                        currentQuestion.question,
                        style: theme.textTheme.titleMedium?.copyWith(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ),
                ),
              ),
              
              const SizedBox(height: 24),
              
              // خيارات الإجابة الأربعة
              Expanded(
                flex: 5,
                child: ListView.builder(
                  itemCount: currentQuestion.options.length,
                  itemBuilder: (context, index) {
                    final option = currentQuestion.options[index];
                    
                    Color btnColor = theme.cardTheme.color ?? Colors.grey.shade900;
                    IconData? rightIcon;
                    
                    if (_isAnswered) {
                      if (index == currentQuestion.correctIndex) {
                        btnColor = Colors.green.withOpacity(0.2);
                        rightIcon = Icons.check_circle;
                      } else if (index == _selectedAnswerIndex) {
                        btnColor = Colors.red.withOpacity(0.2);
                        rightIcon = Icons.cancel;
                      }
                    }
                    
                    return Card(
                      color: btnColor,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: _isAnswered && index == currentQuestion.correctIndex 
                              ? Colors.green 
                              : (_isAnswered && index == _selectedAnswerIndex ? Colors.red : Colors.grey.withOpacity(0.2)),
                          width: 1.5,
                        ),
                      ),
                      margin: const EdgeInsets.only(bottom: 12),
                      child: InkWell(
                        onTap: () => _answerQuestion(index),
                        borderRadius: BorderRadius.circular(12),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Expanded(
                                child: Text(
                                  option,
                                  style: const TextStyle(fontSize: 16),
                                ),
                              ),
                              if (rightIcon != null)
                                Icon(rightIcon, color: rightIcon == Icons.check_circle ? Colors.green : Colors.red),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
              
              const SizedBox(height: 16),
              
              // زر السؤال التالي
              ElevatedButton(
                onPressed: _isAnswered ? _nextQuestion : null,
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                ),
                child: Text(
                  _currentQuestionIndex == _questions.length - 1 ? 'عرض النتيجة النهائية' : 'السؤال التالي',
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
