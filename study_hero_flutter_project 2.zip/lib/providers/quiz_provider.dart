import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/user_stats.dart';

class QuizProvider extends ChangeNotifier {
  late SharedPreferences _prefs;
  late UserStats _userStats;
  bool _isSoundEnabled = true;

  UserStats get userStats => _userStats;
  bool get isSoundEnabled => _isSoundEnabled;
  String get currentTheme => _userStats.currentTheme;

  // تهيئة وحفظ الإعدادات من SharedPreferences
  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
    
    // محاولة جلب الإحصائيات المحفوظة وإلا وضع الإحصائيات الافتراضية
    final statsString = _prefs.getString('study_hero_user_stats');
    if (statsString != null) {
      try {
        _userStats = UserStats.fromJson(jsonDecode(statsString));
      } catch (e) {
        _userStats = UserStats.defaultStats();
      }
    } else {
      _userStats = UserStats.defaultStats();
    }

    _isSoundEnabled = _prefs.getBool('is_sound_enabled') ?? true;
    notifyListeners();
  }

  // حفظ الإحصائيات في الذاكرة المحلية SharedPreferences
  Future<void> saveStats() async {
    await _prefs.setString('study_hero_user_stats', jsonEncode(_userStats.toJson()));
    notifyListeners();
  }

  // تحديث الاسم عند التسجيل
  Future<void> setUsername(String name) async {
    _userStats = UserStats(
      username: name,
      coins: _userStats.coins,
      xp: _userStats.xp,
      playerLevel: _userStats.playerLevel,
      unlockedAvatars: _userStats.unlockedAvatars,
      currentAvatar: _userStats.currentAvatar,
      unlockedThemes: _userStats.unlockedThemes,
      currentTheme: _userStats.currentTheme,
      completedAchievements: _userStats.completedAchievements,
      subjectLevelsProgress: _userStats.subjectLevelsProgress,
    );
    await saveStats();
  }

  // إضافة عملات ونقاط خبرة عند الإجابة الصحيحة
  Future<void> addRewards(int xpAmount, int coinsAmount) async {
    int newXp = _userStats.xp + xpAmount;
    int currentLvl = _userStats.playerLevel;
    
    // معادلة لترقية مستوى اللاعب: كل 100 XP تزيد مستوى
    int nextLevelThreshold = currentLvl * 100;
    while (newXp >= nextLevelThreshold) {
      newXp -= nextLevelThreshold;
      currentLvl++;
      nextLevelThreshold = currentLvl * 100;
      
      // إنجاز ترقية المستوى الأول
      unlockAchievement('level_up');
    }

    _userStats = UserStats(
      username: _userStats.username,
      coins: _userStats.coins + coinsAmount,
      xp: newXp,
      playerLevel: currentLvl,
      unlockedAvatars: _userStats.unlockedAvatars,
      currentAvatar: _userStats.currentAvatar,
      unlockedThemes: _userStats.unlockedThemes,
      currentTheme: _userStats.currentTheme,
      completedAchievements: _userStats.completedAchievements,
      subjectLevelsProgress: _userStats.subjectLevelsProgress,
    );
    await saveStats();
  }

  // الحصول على المكافأة اليومية (20 قطعة نقدية)
  Future<bool> claimDailyReward() async {
    final lastClaimedStr = _prefs.getString('last_daily_claim');
    final todayStr = DateTime.now().toIso8601String().substring(0, 10);
    
    if (lastClaimedStr == todayStr) {
      return false; // تم الحصول عليها مسبقاً اليوم
    }

    await _prefs.setString('last_daily_claim', todayStr);
    
    // إضافة 20 كوينز
    _userStats = UserStats(
      username: _userStats.username,
      coins: _userStats.coins + 20,
      xp: _userStats.xp,
      playerLevel: _userStats.playerLevel,
      unlockedAvatars: _userStats.unlockedAvatars,
      currentAvatar: _userStats.currentAvatar,
      unlockedThemes: _userStats.unlockedThemes,
      currentTheme: _userStats.currentTheme,
      completedAchievements: _userStats.completedAchievements,
      subjectLevelsProgress: _userStats.subjectLevelsProgress,
    );
    unlockAchievement('daily_claim');
    await saveStats();
    return true;
  }

  // فتح وإنجاز مستوى جديد
  Future<void> unlockNextLevel(String subjectId, int completedLevel) async {
    final currentUnlocked = _userStats.subjectLevelsProgress[subjectId] ?? 1;
    if (completedLevel == currentUnlocked && currentUnlocked < 5) {
      final updatedProgress = Map<String, int>.from(_userStats.subjectLevelsProgress);
      updatedProgress[subjectId] = currentUnlocked + 1;

      _userStats = UserStats(
        username: _userStats.username,
        coins: _userStats.coins,
        xp: _userStats.xp,
        playerLevel: _userStats.playerLevel,
        unlockedAvatars: _userStats.unlockedAvatars,
        currentAvatar: _userStats.currentAvatar,
        unlockedThemes: _userStats.unlockedThemes,
        currentTheme: _userStats.currentTheme,
        completedAchievements: _userStats.completedAchievements,
        subjectLevelsProgress: updatedProgress,
      );

      // التحقق من إنجاز 'كل المستويات مفتوحة'
      bool allMax = true;
      updatedProgress.forEach((key, val) {
        if (val < 5) allMax = false;
      });
      if (allMax) {
        unlockAchievement('conqueror');
      }

      await saveStats();
    }
  }

  // فك القفل وإلغاء حظر الإنجازات
  void unlockAchievement(String achievementId) {
    if (!_userStats.completedAchievements.contains(achievementId)) {
      final updatedAchievements = List<String>.from(_userStats.completedAchievements)..add(achievementId);
      
      _userStats = UserStats(
        username: _userStats.username,
        coins: _userStats.coins + 50, // مكافأة إنجاز 50 كوينز!
        xp: _userStats.xp,
        playerLevel: _userStats.playerLevel,
        unlockedAvatars: _userStats.unlockedAvatars,
        currentAvatar: _userStats.currentAvatar,
        unlockedThemes: _userStats.unlockedThemes,
        currentTheme: _userStats.currentTheme,
        completedAchievements: updatedAchievements,
        subjectLevelsProgress: _userStats.subjectLevelsProgress,
      );
      saveStats();
    }
  }

  // شراء وتفعيل الأفاتار الجديد
  Future<bool> buyAvatar(String avatarId, int price) async {
    if (_userStats.unlockedAvatars.contains(avatarId)) {
      // تم شراؤه مسبقاً، فقط نقوم بتفعيله
      _userStats = UserStats(
        username: _userStats.username,
        coins: _userStats.coins,
        xp: _userStats.xp,
        playerLevel: _userStats.playerLevel,
        unlockedAvatars: _userStats.unlockedAvatars,
        currentAvatar: avatarId,
        unlockedThemes: _userStats.unlockedThemes,
        currentTheme: _userStats.currentTheme,
        completedAchievements: _userStats.completedAchievements,
        subjectLevelsProgress: _userStats.subjectLevelsProgress,
      );
      await saveStats();
      return true;
    }

    if (_userStats.coins >= price) {
      final updatedAvatars = List<String>.from(_userStats.unlockedAvatars)..add(avatarId);
      _userStats = UserStats(
        username: _userStats.username,
        coins: _userStats.coins - price,
        xp: _userStats.xp,
        playerLevel: _userStats.playerLevel,
        unlockedAvatars: updatedAvatars,
        currentAvatar: avatarId,
        unlockedThemes: _userStats.unlockedThemes,
        currentTheme: _userStats.currentTheme,
        completedAchievements: _userStats.completedAchievements,
        subjectLevelsProgress: _userStats.subjectLevelsProgress,
      );
      
      if (updatedAvatars.length >= 5) {
        unlockAchievement('avatar_collector');
      }
      
      await saveStats();
      return true;
    }
    return false; // رصيد غير كافي
  }

  // شراء وتفعيل القالب الجديد (الثيم)
  Future<bool> buyTheme(String themeName, int price) async {
    if (_userStats.unlockedThemes.contains(themeName)) {
      _userStats = UserStats(
        username: _userStats.username,
        coins: _userStats.coins,
        xp: _userStats.xp,
        playerLevel: _userStats.playerLevel,
        unlockedAvatars: _userStats.unlockedAvatars,
        currentAvatar: _userStats.currentAvatar,
        unlockedThemes: _userStats.unlockedThemes,
        currentTheme: themeName,
        completedAchievements: _userStats.completedAchievements,
        subjectLevelsProgress: _userStats.subjectLevelsProgress,
      );
      await saveStats();
      return true;
    }

    if (_userStats.coins >= price) {
      final updatedThemes = List<String>.from(_userStats.unlockedThemes)..add(themeName);
      _userStats = UserStats(
        username: _userStats.username,
        coins: _userStats.coins - price,
        xp: _userStats.xp,
        playerLevel: _userStats.playerLevel,
        unlockedAvatars: _userStats.unlockedAvatars,
        currentAvatar: _userStats.currentAvatar,
        unlockedThemes: updatedThemes,
        currentTheme: themeName,
        completedAchievements: _userStats.completedAchievements,
        subjectLevelsProgress: _userStats.subjectLevelsProgress,
      );
      await saveStats();
      return true;
    }
    return false;
  }

  // تشغيل / إطفاء المؤثرات الصوتية
  Future<void> toggleSound(bool enabled) async {
    _isSoundEnabled = enabled;
    await _prefs.setBool('is_sound_enabled', enabled);
    notifyListeners();
  }

  // إعادة ضبط كامل بيانات اللعبة
  Future<void> resetAllData() async {
    _userStats = UserStats.defaultStats();
    await _prefs.remove('study_hero_user_stats');
    await _prefs.remove('last_daily_claim');
    _isSoundEnabled = true;
    await _prefs.setBool('is_sound_enabled', true);
    await saveStats();
  }
}
