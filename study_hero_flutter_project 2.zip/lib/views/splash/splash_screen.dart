import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import '../../providers/quiz_provider.dart';
import '../auth/login_screen.dart';
import '../home/home_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _navigateToNextScreen();
  }

  void _navigateToNextScreen() async {
    // محاكاة تأخير شاشة البداية لرؤية شعار التطبيق المذهل
    await Future.delayed(const Duration(milliseconds: 2500));
    
    if (!mounted) return;
    
    final provider = Provider.of<QuizProvider>(context, listen: false);
    
    // إذا كان المستخدم جديداً نفتح شاشة التسجيل وإلا شاشة البداية الرئيسية مباشرة
    if (provider.userStats.username == 'بطل الدراسة') {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const LoginScreen()),
      );
    } else {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const HomeScreen()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // الشعار اللطيف بطل الدراسة محاط بدوائر مضيئة مع تأثير أنيميشن
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: theme.colorScheme.primary.withOpacity(0.15),
                shape: BoxShape.circle,
                border: Border.all(color: theme.colorScheme.primary, width: 2),
              ),
              child: Icon(
                Icons.emoji_events,
                size: 80,
                color: theme.colorScheme.primary,
              ),
            )
            .animate()
            .fade(duration: 800.ms)
            .scale(delay: 200.ms, duration: 600.ms, curve: Curves.bounceOut),
            
            const SizedBox(height: 24),
            
            Text(
              'StudyHero',
              style: theme.textTheme.headlineMedium?.copyWith(
                fontWeight: FontWeight.bold,
                color: theme.colorScheme.primary,
                letterSpacing: 1.5,
              ),
            )
            .animate()
            .slideY(begin: 0.3, end: 0, duration: 600.ms)
            .fade(duration: 600.ms),
            
            const SizedBox(height: 8),
            
            Text(
              'اصنع من علمك قوة وبطولة!',
              style: theme.textTheme.bodyMedium?.copyWith(
                color: theme.colorScheme.onBackground.withOpacity(0.7),
              ),
            )
            .animate()
            .fade(delay: 500.ms, duration: 600.ms),
            
            const SizedBox(height: 48),
            
            // مؤشر التحميل الدائري المخصص متناسق مع الألوان الأرجوانية الداكنة
            CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(theme.colorScheme.primary),
            )
            .animate()
            .fade(delay: 1000.ms),
          ],
        ),
      ),
    );
  }
}
