class UserStats {
  final String username;
  final int coins;
  final int xp;
  final int playerLevel;
  final List<String> unlockedAvatars;
  final String currentAvatar;
  final List<String> unlockedThemes;
  final String currentTheme;
  final List<String> completedAchievements;
  final Map<String, int> subjectLevelsProgress; // subjectId -> unlockedLevel (1-5)

  UserStats({
    required this.username,
    required this.coins,
    required this.xp,
    required this.playerLevel,
    required this.unlockedAvatars,
    required this.currentAvatar,
    required this.unlockedThemes,
    required this.currentTheme,
    required this.completedAchievements,
    required this.subjectLevelsProgress,
  });

  factory UserStats.defaultStats() {
    return UserStats(
      username: 'بطل الدراسة',
      coins: 50,
      xp: 0,
      playerLevel: 1,
      unlockedAvatars: ['avatar_1'], // الأفاتار الأول مجاني
      currentAvatar: 'avatar_1',
      unlockedThemes: ['dark_purple'], // الثيم الأول مجاني
      currentTheme: 'dark_purple',
      completedAchievements: [],
      subjectLevelsProgress: {
        'math': 1,
        'science': 1,
        'english': 1,
        'history': 1,
      },
    );
  }

  // تحويل الإحصائيات لتخزينها في SharedPreferences كـ JSON
  factory UserStats.fromJson(Map<String, dynamic> json) {
    return UserStats(
      username: json['username'] ?? 'بطل الدراسة',
      coins: json['coins'] ?? 0,
      xp: json['xp'] ?? 0,
      playerLevel: json['playerLevel'] ?? 1,
      unlockedAvatars: List<String>.from(json['unlockedAvatars'] ?? ['avatar_1']),
      currentAvatar: json['currentAvatar'] ?? 'avatar_1',
      unlockedThemes: List<String>.from(json['unlockedThemes'] ?? ['dark_purple']),
      currentTheme: json['currentTheme'] ?? 'dark_purple',
      completedAchievements: List<String>.from(json['completedAchievements'] ?? []),
      subjectLevelsProgress: Map<String, int>.from(json['subjectLevelsProgress'] ?? {
        'math': 1,
        'science': 1,
        'english': 1,
        'history': 1,
      }),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'username': username,
      'coins': coins,
      'xp': xp,
      'playerLevel': playerLevel,
      'unlockedAvatars': unlockedAvatars,
      'currentAvatar': currentAvatar,
      'unlockedThemes': unlockedThemes,
      'currentTheme': currentTheme,
      'completedAchievements': completedAchievements,
      'subjectLevelsProgress': subjectLevelsProgress,
    };
  }
}
