import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/quiz_provider.dart';

class LeaderboardScreen extends StatelessWidget {
  const LeaderboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final quizProvider = Provider.of<QuizProvider>(context);
    final stats = quizProvider.userStats;

    // قائمة المتصدرين الافتراضية
    final List<Map<String, dynamic>> leaders = [
      {'username': 'سارة أحمد (الملكة)', 'level': 24, 'xp': 2450, 'rank': 1},
      {'username': 'البطل يوسف', 'level': 19, 'xp': 1980, 'rank': 2},
      {'username': 'الأستاذة فاطمة', 'level': 17, 'xp': 1720, 'rank': 3},
      {'username': stats.username, 'level': stats.playerLevel, 'xp': stats.xp, 'rank': 4}, // موقع اللاعب الحالي
      {'username': 'خالد سليم', 'level': 12, 'xp': 1250, 'rank': 5},
      {'username': 'عمر الخطيب', 'level': 8, 'xp': 840, 'rank': 6},
    ];

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      appBar: AppBar(
        title: const Text('قائمة متصدري الأسبوع'),
      ),
      body: Column(
        children: [
          // لوحة الميداليات الثلاثية الذهبية والفضية والبرونزية للمتصدري القمة
          Container(
            padding: const EdgeInsets.symmetric(vertical: 20),
            color: theme.colorScheme.surface.withOpacity(0.5),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                // المركز الثاني
                _buildPodiumItem(context, 'يوسف', '2', Colors.grey, 70),
                // المركز الأول
                _buildPodiumItem(context, 'سارة', '1', Colors.amber, 90),
                // المركز الثالث
                _buildPodiumItem(context, 'فاطمة', '3', Colors.brown, 60),
              ],
            ),
          ),
          
          const Divider(height: 1),
          
          // باقي قائمة المتصدرين
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              itemCount: leaders.length,
              itemBuilder: (context, index) {
                final leader = leaders[index];
                final isMe = leader['username'] == stats.username;
                
                return Card(
                  color: isMe ? theme.colorScheme.primary.withOpacity(0.15) : null,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: isMe ? theme.colorScheme.primary : Colors.transparent,
                    ),
                  ),
                  child: ListTile(
                    leading: CircleAvatar(
                      backgroundColor: _getRankColor(leader['rank']),
                      child: Text(
                        '${leader['rank']}',
                        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                      ),
                    ),
                    title: Text(
                      leader['username'],
                      style: TextStyle(fontWeight: isMe ? FontWeight.bold : FontWeight.normal),
                    ),
                    subtitle: Text('المستوى ${leader['level']}'),
                    trailing: Text(
                      '${leader['xp']} XP',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: theme.colorScheme.primary,
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPodiumItem(BuildContext context, String name, String rank, Color color, double height) {
    final theme = Theme.of(context);
    
    return Column(
      children: [
        CircleAvatar(
          backgroundColor: color.withOpacity(0.2),
          child: Icon(Icons.person, color: color),
        ),
        const SizedBox(height: 8),
        Text(name, style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Container(
          width: 60,
          height: height,
          decoration: BoxDecoration(
            color: color,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(8)),
          ),
          child: Center(
            child: Text(
              '#${rank}',
              style: const TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 18),
            ),
          ),
        ),
      ],
    );
  }

  Color _getRankColor(int rank) {
    switch (rank) {
      case 1:
        return Colors.amber;
      case 2:
        return Colors.grey;
      case 3:
        return Colors.brown;
      default:
        return Colors.purple.shade900;
    }
  }
}
