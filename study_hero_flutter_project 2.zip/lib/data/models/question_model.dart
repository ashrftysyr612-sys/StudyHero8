class QuestionModel {
  final String id;
  final String question;
  final List<String> options;
  final int correctIndex;

  QuestionModel({
    required this.id,
    required this.question,
    required this.options,
    required this.correctIndex,
  });

  // تحويل البيانات من JSON لتسهيل التعامل مع قواعد البيانات أو الملفات المحلية
  factory QuestionModel.fromJson(Map<String, dynamic> json) {
    return QuestionModel(
      id: json['id'] as String,
      question: json['question'] as String,
      options: List<String>.from(json['options'] as List),
      correctIndex: json['correctIndex'] as int,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'question': question,
      'options': options,
      'correctIndex': correctIndex,
    };
  }
}
